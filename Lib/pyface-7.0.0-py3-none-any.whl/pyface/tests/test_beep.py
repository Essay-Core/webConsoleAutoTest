# (C) Copyright 2005-2020 Enthought, Inc., Austin, TX
# All rights reserved.
#
# This software is provided without warranty under the terms of the BSD
# license included in LICENSE.txt and may be redistributed only under
# the conditions described in the aforementioned license. The license
# is also available online at http://www.enthought.com/licenses/BSD.txt
#
# Thanks for using Enthought open source!


import unittest

from traits.testing.unittest_tools import UnittestTools

from ..beep import beep


class TestBeep(unittest.TestCase):
    def test_beep(self):
        # does it call without error - the best we can do
        beep()
